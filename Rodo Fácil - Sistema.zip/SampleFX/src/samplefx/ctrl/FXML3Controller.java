/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package samplefx.ctrl;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class FXML3Controller implements Initializable {
	@FXML
	Button btnSalvar = new Button();

	@FXML
	TextField txtNome = new TextField();

	@FXML
	TextField txtpreco = new TextField();

	@FXML
	ComboBox<String> cbDepartamento = new ComboBox<String>();

	@FXML
	TextField txtAltura = new TextField();

	@FXML
	TextField txtLargura = new TextField();

	@FXML
	TextField txtComprimento = new TextField();

	@FXML
	Button btnCancelar = new Button();
	/**
	 * Initializes the controller class.
	 */

	ProdutoDao pdao = new ProdutoDao();
	DepartamentoDao ddao = new DepartamentoDao();
	private static Connection connection;

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		connection = DbUtil.getConnection();
		ObservableList<String> Lista = FXCollections.observableArrayList();
		ResultSet rs;
		try {
			rs = connection.createStatement().executeQuery("SELECT * FROM Departamento");
			while (rs.next()) {
				Lista.add(new String(rs.getString("nome")));
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		cbDepartamento.getItems().addAll(Lista);
		new ComboBoxAutoComplete<String>(cbDepartamento);
	}

	public void showConfirmationProduto() throws SQLException {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Produto");
		alert.setHeaderText("Tem certeza de que deseja cadastrar este Produto?");
		alert.setContentText("Por favor, confirme a opera��o");
		Optional<ButtonType> option = alert.showAndWait();

		if (option.get() == null) {

		} else if (option.get() == ButtonType.OK) {
			InserirProduto();
		} else if (option.get() == ButtonType.CANCEL) {
			LimpaCampos();
		} else {

		}
	}

	public void InserirProduto() {
		if (txtpreco.getText().length() == 0 || (txtAltura.getText().length() == 0 || txtLargura.getText().length() == 0
				|| txtComprimento.getText().length() == 0
				|| cbDepartamento.getSelectionModel().getSelectedIndex() == -1)) {
			ExibeMensagem("Preencha todos os campos!", "Preencha todos os campos!", "Preencha todos os campos!");
			return;

		}

		if (txtpreco.getText().length() != 0) {
			try {
				Double.parseDouble(txtpreco.getText());
				if (Double.parseDouble(txtpreco.getText()) < 0) {
					throw new IllegalArgumentException("");
				}
			} catch (Exception e) {
				ExibeMensagem("O pre�o deve ser num�rico e maior que zero!",
						"O pre�o deve ser num�rico, ser separado por '.' e maior que 0!",
						"O pre�o deve ser num�rico, ser separado por '.' e maior que zero!");
				return;
			}
		}

		if (txtAltura.getText().length() != 0) {
			try {
				Integer.parseInt(txtAltura.getText());
				if (Integer.parseInt(txtAltura.getText()) < 0) {
					throw new IllegalArgumentException("");
				}
			} catch (Exception e) {
				ExibeMensagem("A altura deve ser num�rica, inteira e maior que zero!", "A altura deve ser num�rica, inteira e maior que zero!",
						"A altura deve ser num�rica, inteira e maior que zero!");
				return;
			}
		}

		if (txtLargura.getText().length() != 0) {
			try {
				Integer.parseInt(txtLargura.getText());
				if (Integer.parseInt(txtLargura.getText()) < 0) {
					throw new IllegalArgumentException("");
				}
			} catch (Exception e) {
				ExibeMensagem("A largura deve ser num�rica, inteira e maior que zero!", "A largura deve ser num�rica, inteira e maior que zero!",
						"A largura deve ser num�rica, inteira e maior que zero!");
				return;
			}
		}
		
		if (txtComprimento.getText().length() != 0) {
			try {
				Integer.parseInt(txtComprimento.getText());
				if (Integer.parseInt(txtComprimento.getText()) < 0) {
					throw new IllegalArgumentException("");
				}
			} catch (Exception e) {
				ExibeMensagem("O comprimento deve ser num�rica, inteira e maior que zero!", "O comprimento deve ser num�rica, inteira e maior que zero!",
						"O comprimento deve ser num�rica, inteira e maior que zero!");
				return;
			}
		}

		if (txtLargura.getText().length() >= 4) {
			ExibeMensagem("A largura m�xima � 999!", "A largura m�xima � 999!", "A largura m�xima � 999!");
			return;
		}

		if (txtAltura.getText().length() >= 4) {
			ExibeMensagem("A altura m�xima � 999!", "A altura m�xima � 999!", "A altura m�xima � 999!");
			return;
		}

		if (txtComprimento.getText().length() >= 4) {
			ExibeMensagem("O pre�o m�ximo � R$999!", "O pre�o m�ximo � R$999!", "O pre�o m�ximo � R$999!");
			return;
		}

		if (txtComprimento.getText().length() != 0) {
			try {
				Integer.parseInt(txtComprimento.getText());
			} catch (Exception e) {
				ExibeMensagem("O comprimento deve ser num�rico!", "O comprimento deve ser num�rico!",
						"O comprimento deve ser num�rico!");
				return;
			}
		}

		if (txtNome.getText().length() == 0) {
			ExibeMensagem("Nome!", "Preencha o nome do Produto!", "Preencha o nome do produto!");
			return;
		}

		// (String nome, double preco, int altura, int largura, int comprimento)
		Produto p = new Produto(txtNome.getText(), Double.parseDouble(txtpreco.getText()),
				Integer.parseInt(txtAltura.getText()), Integer.parseInt(txtLargura.getText()),
				Integer.parseInt(txtComprimento.getText()), String.valueOf(cbDepartamento.getValue().toString()));
		pdao.addProduto(p);
		LimpaCampos();
		showAlertWithHeaderText();
	}

	public void Cancelar(ActionEvent event) {
		// (String nome, double preco, int altura, int largura, int comprimento)
		LimpaCampos();
	}

	private void showAlertWithHeaderText() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Produto Inserido");
		alert.setHeaderText("Produto Inserido com Sucesso!");
		alert.setContentText("O Produto foi inserido na base de dados!");
		alert.showAndWait();
	}

	private void ExibeMensagem(String title, String header, String Content) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(Content);
		alert.showAndWait();
	}

	public void LimpaCampos() {
		txtNome.clear();
		txtpreco.clear();
		txtAltura.clear();
		txtLargura.clear();
		txtComprimento.clear();
		cbDepartamento.setValue("");
		txtNome.requestFocus();
	}

}
