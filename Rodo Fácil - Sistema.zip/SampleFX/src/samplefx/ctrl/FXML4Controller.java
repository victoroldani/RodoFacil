/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package samplefx.ctrl;

import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class FXML4Controller implements Initializable {
	@FXML
	Button btnSalvar = new Button(); 
	
	@FXML
	TextField txtNome = new TextField();
	
	@FXML
	Button btnCancelar = new Button(); 
	
	DepartamentoDao pdao = new DepartamentoDao();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
    public void InserirDepartamento () {
    	if (txtNome.getText().length() == 0) {
    		ExibeMensagem();
    		return;
    	}
    	Departamento p = new Departamento();
    	p.setNome(txtNome.getText());
    	pdao.InserirDepartamento(p);
    	showAlertWithHeaderText();
    	LimpaCampos();
    }
    
    
    private void showAlertWithHeaderText() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Departamento Inserido");
        alert.setHeaderText("Departamento Inserido com Sucesso!");
        alert.setContentText("O Departamento foi inserido na base de dados!");
        alert.showAndWait();
    }
    
    public void showConfirmationDepartamento () throws SQLException {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Departamento");
        alert.setHeaderText("Tem certeza de que deseja cadastrar este departamento?");
        alert.setContentText("Por favor, confirme a opera��o");
        Optional<ButtonType> option = alert.showAndWait();
   
        if (option.get() == null) {
           
        } else if (option.get() == ButtonType.OK) {
        	InserirDepartamento();
        } else if (option.get() == ButtonType.CANCEL) {
        	LimpaCampos();
        } else {
           
        }
     }

    private void ExibeMensagem() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Preencha o nome do departamento!");
        alert.setHeaderText("Preencha o nome do departamento!");
        alert.setContentText("Preencha o nome do departamento!");
        alert.showAndWait();
    }
    
    public void Cancelar (ActionEvent event){
    	LimpaCampos();
    }
    
    public void LimpaCampos() {
    	txtNome.clear();
    	txtNome.requestFocus();
    }
    
}