/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package samplefx.ctrl;
import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class FXML5Controller implements Initializable {
	
	@FXML
	DatePicker txtDataInicial = new DatePicker();
	
	@FXML
	DatePicker txtDataFinal = new DatePicker();
	
	@FXML
	Button btnCancelar = new Button(); 
	
	@FXML
	Button btnRelatorioAnalitico  = new Button(); 
	
	@FXML
	Button btnOK = new Button();
	
	@FXML
	CheckBox cbValorTotal = new CheckBox();
	
	VendaDao vdao = new VendaDao();
	
	Double valor = 0.0;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    private void ExibeMensagem(String title, String header, String content) {
		Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
	}
    
    public void Cancelar (ActionEvent event){
    	LimpaCampos();
    }
    
    private void LimpaCampos () {
    	txtDataInicial.setValue(null);
    	txtDataFinal.setValue(null);
    	txtDataInicial.requestFocus();
    }
    
    
    public void AbrirQVD (ActionEvent event) throws Exception{
        File csvOutputFile = new File("RodoFacil_teste.qvw");
        Desktop desktop = Desktop.getDesktop();
        if (csvOutputFile.exists()) desktop.open(csvOutputFile);
    }
    public void GerarRelat (ActionEvent event) throws Exception{
    	
    	GregorianCalendar calendar = new GregorianCalendar();
    	
    	int dia = calendar.get(GregorianCalendar.DAY_OF_MONTH);
    	int mes = calendar.get(GregorianCalendar.MONTH) + 1;
    	int ano = calendar.get(GregorianCalendar.YEAR);
    	
    	String dataInicial = "01/01/2018";
    	String dataFinal = String.valueOf(dia) + "/" + String.valueOf(mes) + "/" + String.valueOf(ano);
    	String DataInicialPicker = "";
    	String DataFinalPicker = "";
    	
    	if (txtDataInicial.getValue() != null) {
    		try {
    			dataInicial = txtDataInicial.getValue().toString().substring(8, 10) + "/" + txtDataInicial.getValue().toString().substring(5, 7) + "/" + txtDataInicial.getValue().toString().substring(0, 4);
    		}
    		catch (Exception e) {
    			ExibeMensagem("Datas Inv�lidas!", "Preencha os campos com datas v�lidas!", "Preencha os campos com datas v�lidas!");
    		}
    	}
    	
    	if (txtDataFinal.getValue() != null ) {
    		try {
    			dataFinal = txtDataFinal.getValue().toString().substring(8, 10) + "/" + txtDataFinal.getValue().toString().substring(5, 7) + "/" + txtDataFinal.getValue().toString().substring(0, 4);
    		}
    		catch (Exception e) {
    			ExibeMensagem("Datas Inv�lidas!", "Preencha os campos com datas v�lidas!", "Preencha os campos com datas v�lidas!");
    		}
    	}
    	
    	if (txtDataInicial.getValue() == null && txtDataFinal.getValue() == null) {
    		VendaDao.printToCsv(vdao.fetchDataFromDatabase("select * from venda"),  vdao.CalculaValor(dataInicial, dataFinal), cbValorTotal.isSelected());
    		return;
    	}
    	else if (txtDataInicial.getValue() == null && txtDataFinal.getValue() != null) {
    		VendaDao.printToCsv(vdao.fetchDataFromDatabase("select * from venda v where convert(date , substring(v.data_venda,7,10) + '/' + substring(v.data_venda,4,2) + '/' + substring(v.data_venda,1,2)) < convert(date , substring('" + dataFinal  + "',7,10) + '/' + substring('" + dataFinal  + "',4,2) + '/' + substring('" + dataFinal  + "',1,2))"),  vdao.CalculaValor(dataInicial, dataFinal), cbValorTotal.isSelected());
    		return;
    	}
    	
    	else if (txtDataInicial.getValue() != null && txtDataFinal.getValue() == null) {
    		VendaDao.printToCsv(vdao.fetchDataFromDatabase("select * from venda v where convert(date , substring(v.data_venda,7,10) + '/' + substring(v.data_venda,4,2) + '/' + substring(v.data_venda,1,2)) > convert(date , substring('" + dataInicial  + "',7,10) + '/' + substring('" + dataInicial  + "',4,2) + '/' + substring('" + dataInicial  + "',1,2))"),  vdao.CalculaValor(dataInicial, dataFinal), cbValorTotal.isSelected());
    		return;
    	}
    	else {
    		if (txtDataInicial.getValue().isAfter(txtDataFinal.getValue())) {
    			ExibeMensagem("Data!", "A data inicial n�o pode ser maior que a data final!", "A data inicial n�o pode ser maior que a data final");
    			return;
    		}
    		
    		try {
    			VendaDao.printToCsv(vdao.fetchDataFromDatabase("select * from venda v where convert(date , substring(v.data_venda,7,10) + '/' + substring(v.data_venda,4,2) + '/' + substring(v.data_venda,1,2)) between convert(date , substring('"+ dataInicial +"',7,10) + '/' + substring('"+ dataInicial +"',4,2) + '/' + substring('"+ dataInicial +"',1,2)) and convert(date , substring('"+ dataFinal +"',7,10) + '/' + substring('"+ dataFinal +"',4,2) + '/' + substring('"+ dataFinal +"',1,2))"),  vdao.CalculaValor(dataInicial, dataFinal), cbValorTotal.isSelected());
    		} 	catch (Exception e) {
    			e.printStackTrace();
    		}  
    	}
    	LimpaCampos();
    }
}