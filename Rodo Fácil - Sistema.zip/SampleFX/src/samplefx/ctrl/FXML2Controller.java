/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package samplefx.ctrl;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

public class FXML2Controller implements Initializable {
	
	@FXML
	Button btnRegistrar = new Button(); 
	
	@FXML
	Button btnDeletar = new Button(); 
	
	@FXML
	Button btnAdicionar = new Button(); 
	
	@FXML
	TableView<ProdAux> tbItens = new TableView();
	
	@FXML
	Button btnCancelar = new Button(); 
	
	@FXML
	TextField txtQuantidade = new TextField();
	
	@FXML
	ComboBox<String> cbProdutos = new ComboBox<String>();
	
	@FXML
	Label lblValor = new Label();
	
	int contagem = 0;
	ProdutoDao pdao = new ProdutoDao();
	VendaDao vdao = new VendaDao();
	ItemVendaDao ivdao = new ItemVendaDao();
	private static Connection connection;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    	connection = DbUtil.getConnection();
    	TableColumn colunaNome = new TableColumn("Produto");
		colunaNome.setCellValueFactory(new PropertyValueFactory<>("nome"));

		TableColumn colunaQuantidade = new TableColumn("Quantidade");
		colunaQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
		
		tbItens.getColumns().clear();
		tbItens.getColumns().addAll(colunaNome, colunaQuantidade);
		colunaNome.setPrefWidth(535);
    	
    	ObservableList<String> Lista = FXCollections.observableArrayList();
    	ResultSet rs;
		try {
			rs = connection.createStatement().executeQuery("SELECT * FROM Produto;");
			while (rs.next()) {
				Lista.add(new String(rs.getString("nome"))); 
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	cbProdutos.getItems().addAll(Lista);
		new ComboBoxAutoComplete<String>(cbProdutos);
    }
    
    public void showConfirmationEstoque () throws SQLException {
    	
		if (contagem == 0) {
			ExibeMensagem("Escolha pelo menos 1 Produto!", "Escolha pelo menos 1 Produto!", "N�o � poss�vel cadastrar uma venda sem nenhum produto!");
			return;
		}
		
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Estoque");
        alert.setHeaderText("Tem certeza de que deseja Atualizar o estoque?");
        alert.setContentText("Por favor, confirme a opera��o");
        Optional<ButtonType> option = alert.showAndWait();
   
        if (option.get() == null) {
           
        } else if (option.get() == ButtonType.OK) {
        	AtualizarEstoque();
        } else if (option.get() == ButtonType.CANCEL) {
        	LimpaCampos();
        } else {
           
        }
     }
    
    public void AddTable () throws SQLException {
    	
    	try {
			Integer.parseInt(txtQuantidade.getText());
			if (txtQuantidade.getText().length() >= 4) {
    			ExibeMensagem("A quantidade m�xima � 999!", "A quantidade m�xima � 999!", "A quantidade m�xima � 999!");
        		return;
    		}
		}
		catch (NumberFormatException e) {
			ExibeMensagem("'Quantidade' deve ser num�rico, inteiro, e menor que 999!", "'Quantidade' deve ser num�rico, inteiro, e menor que 999!", "'Quantidade' deve ser num�rico, inteiro, e menor que 999!");
			return;
		}

    	if (txtQuantidade.getText().length() == 0) {
			ExibeMensagem("Escolha um produto e especifique a quantidade antes de Atualizar o estoque!", "Especifique um produto e uma quantidade!", "N�o foi poss�vel atualizar o estoque pois nenhum produto/ quantidade foi especificado!");
			return;
		}
    	
    	if (cbProdutos.getSelectionModel().getSelectedIndex() == -1) {
    		ExibeMensagem("Escolha um produto e especifique a quantidade antes de adicionar � venda!", "Especifique um produto e uma quantidade!", "N�o foi poss�vel adicionar � venda pois nenhum produto/ quantidade foi especificado!");
    		return;
    	}
    	
    	if (cbProdutos.getSelectionModel().getSelectedIndex() == -1) {
			ExibeMensagem("Escolha um produto e especifique a quantidade antes de adicionar � venda!", "Especifique um produto e uma quantidade!", "N�o foi poss�vel adicionar � venda pois nenhum produto/ quantidade foi especificado!");
			return;
		}
		
		
		
		if (Integer.parseInt(txtQuantidade.getText()) <= 0) {
			ExibeMensagem("Quantidade!", "Quantidade n�o pode ser negativa!", "Quantidade n�o pode ser negativa!");
    		return;
		}
		
		
    	contagem = contagem + 1;
		ProdAux p = new ProdAux();
		p.setNome(cbProdutos.getValue().toString());
		p.setQuantidade(Integer.parseInt(txtQuantidade.getText()));
		tbItens.getItems().add(p);
		cbProdutos.setValue("");
		cbProdutos.requestFocus();
		txtQuantidade.setText("");
	}
	
	public void DeleteTable () throws SQLException {
		
		ObservableList<ProdAux> selecionado, todos; 
		todos = tbItens.getItems();
		selecionado = tbItens.getSelectionModel().getSelectedItems();
		selecionado.forEach(todos::remove);
	}
	
	public void AtualizarEstoque () throws SQLException {
		if (contagem == 0) {
			ExibeMensagem("Escolha pelo menos 1 Produto!", "Escolha pelo menos 1 Produto!", "N�o � poss�vel cadastrar uma venda sem nenhum produto!");
			return;
		}
		
		ArrayList<String> values = new ArrayList<>();
	    ObservableList<TableColumn<ProdAux, ?>> columns = tbItens.getColumns();

	    for (ProdAux row : tbItens.getItems()) {
	    	pdao.AtualizarEstoque(row.getNome(), row.getQuantidade());
	    }
	    LimpaCampos();
	    ExibirMensagem();
	    contagem = 0;
	}

	public void LimpaCampos () {
		cbProdutos.setValue("");
		txtQuantidade.setText("");
		tbItens.getItems().clear();
		cbProdutos.requestFocus();
		}

	private void ExibirMensagem() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Estoque atualizado!");
		alert.setHeaderText("Estoque atualizado com Sucesso!");
		alert.setContentText("Os produtos foram inseridos no controle de estoque!");
		alert.showAndWait();
	}

	private void ExibeMensagem(String title, String header, String content) {
		Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
	}
    
}
