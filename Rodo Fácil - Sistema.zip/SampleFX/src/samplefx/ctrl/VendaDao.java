package samplefx.ctrl;
import org.apache.poi.*;
import java.awt.Desktop;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.*;

public class VendaDao {
	

	private static Connection connection;
	
	public VendaDao() {
		connection = DbUtil.getConnection();
	}
	
	public void InserirVenda (Venda v) { //mudar para incluir
		
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(
					"INSERT INTO Venda (data_venda, valor) VALUES (?, ?)");
			
			preparedStatement.setString(1, v.getData());
			preparedStatement.setDouble(2, v.getValor());
			preparedStatement.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public int ResgataMaiorID () throws SQLException {
		int ID = 0;
		try {
			Statement st =  connection.createStatement();
			ResultSet rs = st.executeQuery("Select Max(id) from Venda");
			
			while (rs.next()) {
			      int id = rs.getInt(1);
			      return id;
			    }
			
        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
		return ID;
	}
	
	public static void printToCsv(ResultSet resultArray, Double valor, Boolean calcular) throws Exception{
        File csvOutputFile = new File("teste.csv");
        FileWriter fileWriter = new FileWriter(csvOutputFile, false);
        int numCols = resultArray.getMetaData().getColumnCount();
        
        fileWriter.write("N� da Venda" + ";");
    	fileWriter.write("Valor" + ";");
    	fileWriter.write("Data");
    	fileWriter.write("\n" );
    	

    		
        while(resultArray.next()) {
        	fileWriter.write( resultArray.getObject(1).toString() + ";");
        	fileWriter.write( resultArray.getObject(2).toString() + ";");
        	fileWriter.write( resultArray.getObject(3).toString() + "\n");
        	}
        	if (calcular) {
        	fileWriter.write("Valor das vendas no per�odo: R$ " +valor.toString());
        	}
        	fileWriter.close();
        Desktop.getDesktop().open(csvOutputFile);
    }
    
	public ResultSet fetchDataFromDatabase(String selectQuery) throws  Exception{
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(selectQuery);
            return rs;

        } catch (SQLException e) {
        	e.printStackTrace();
        }
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery(selectQuery);
		return rs;
    }
	
	public double CalculaValor(String dataInicial, String dataFinal) {
		double ID = 0;
		try {
			Statement st =  connection.createStatement();
			ResultSet rs = st.executeQuery("select sum(valor) from venda v where convert(date , substring(v.data_venda,7,10) + '/' + substring(v.data_venda,4,2) + '/' + substring(v.data_venda,1,2)) between convert(date , substring('"+ dataInicial +"',7,10) + '/' + substring('"+ dataInicial +"',4,2) + '/' + substring('"+ dataInicial +"',1,2)) and convert(date , substring('"+ dataFinal +"',7,10) + '/' + substring('"+ dataFinal +"',4,2) + '/' + substring('"+ dataFinal +"',1,2))");
			
			while (rs.next()) {
			      double valor = rs.getDouble(1);
			      return valor;
			    }
			
        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
		return ID;
	}
}
