
package samplefx.ctrl;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;

public class FXML1Controller implements Initializable {
	@FXML
	Button btnRegistrar = new Button(); 
	
	@FXML
	Button btnDeletar = new Button(); 
	
	@FXML
	Button btnAdicionar = new Button(); 
	
	@FXML
	TableView<ProdAux> tbItens = new TableView();
	
	@FXML
	Button btnCancelar = new Button(); 
	
	@FXML
	TextField txtQuantidade = new TextField();
	
	@FXML
	ComboBox<String> cbProdutos = new ComboBox<String>();
	
	int contagem = 0;
	
	@FXML
	Label lblValor = new Label();
	
	ProdutoDao pdao = new ProdutoDao();
	VendaDao vdao = new VendaDao();
	ItemVendaDao ivdao = new ItemVendaDao();
	private static Connection connection;
	double valor_total = 0;
	
    /**
     * Initializes the controller class.
     */
	
	@Override
    public void initialize(URL url, ResourceBundle rb) {
		connection = DbUtil.getConnection();
		lblValor.setText( String.valueOf(valor_total));
		
		TableColumn colunaNome = new TableColumn("Produto");
		colunaNome.setCellValueFactory(new PropertyValueFactory<>("nome"));

		TableColumn colunaQuantidade = new TableColumn("Quantidade");
		colunaQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
		
		tbItens.getColumns().clear();
		tbItens.getColumns().addAll(colunaNome, colunaQuantidade);
		colunaNome.setPrefWidth(535);
		
    	ObservableList<String> Lista = FXCollections.observableArrayList();
    	ResultSet rs;
		try {
			rs = connection.createStatement().executeQuery("SELECT * FROM Produto;");
			while (rs.next()) {
				Lista.add(new String(rs.getString("nome"))); 
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	cbProdutos.getItems().addAll(Lista);
		new ComboBoxAutoComplete<String>(cbProdutos);
    }
	
	public void AddTable () throws SQLException {
		
		
		if (cbProdutos.getSelectionModel().getSelectedIndex() == -1) {
    		ExibeMensagem("Escolha um produto e especifique a quantidade antes de adicionar � venda!", "Especifique um produto e uma quantidade!", "N�o foi poss�vel adicionar � venda pois nenhum produto/ quantidade foi especificado!");
    		return;
    	}
		
		if (cbProdutos.getSelectionModel().getSelectedIndex() == -1) {
			ExibeMensagem("Escolha um produto e especifique a quantidade antes de adicionar � venda!", "Especifique um produto e uma quantidade!", "N�o foi poss�vel adicionar � venda pois nenhum produto/ quantidade foi especificado!");
			return;
		}
		
		try {
			Integer.parseInt(txtQuantidade.getText());
		}
		catch (NumberFormatException e) {
			ExibeMensagem("'Quantidade' deve ser num�rico, inteiro, e menor que 999!", "'Quantidade' deve ser num�rico, inteiro, e menor que 999!", "'Quantidade' deve ser num�rico, inteiro, e menor que 999!");
			return;
		}
		
		if (Integer.parseInt(txtQuantidade.getText()) <= 0) {
			ExibeMensagem("Quantidade!", "Quantidade n�o pode ser negativa!", "Quantidade n�o pode ser negativa!");
    		return;
		}
		
		if (txtQuantidade.getText().length() >= 4) {
			ExibeMensagem("A quantidade m�xima � 999!", "A quantidade m�xima � 999!", "A quantidade m�xima � 999!");
    		return;
		}
		
		ProdAux p = new ProdAux();
		p.setNome(cbProdutos.getValue().toString());
		p.setQuantidade(Integer.parseInt(txtQuantidade.getText()));
		tbItens.getItems().add(p);
		cbProdutos.setValue("");
		cbProdutos.requestFocus();
		txtQuantidade.setText("");
		contagem = contagem + 1;
		valor_total += (pdao.ConsultaPreco(p.getNome()) * p.getQuantidade());
		lblValor.setText( String.valueOf(valor_total));
	}
	
	public void DeleteTable () throws SQLException {
		
		ObservableList<ProdAux> selecionado, todos; 
		todos = tbItens.getItems();
		selecionado = tbItens.getSelectionModel().getSelectedItems();
		
		for(ProdAux aux: selecionado){
			valor_total -= (pdao.ConsultaPreco(aux.getNome()) * aux.getQuantidade());
			}
		
		selecionado.forEach(todos::remove);
		lblValor.setText( String.valueOf(valor_total));
	}
	
	public void RegistrarVenda() throws SQLException {
		Venda v = new Venda();
		Date d = new java.util.Date();
		String data = String.valueOf(d);
	    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	    
		v.setData(sdf.format(d));
		v.setValor(valor_total);
		vdao.InserirVenda(v);
		
		ArrayList<String> values = new ArrayList<>();
	    ObservableList<TableColumn<ProdAux, ?>> columns = tbItens.getColumns();

	    for (ProdAux row : tbItens.getItems()) {
	    	
	    	ItemVenda iv = new ItemVenda();
	    	String nome = row.getNome();
	    	iv.setIdProduto(pdao.ConsultaID(nome));
	    	iv.setIdVenda(vdao.ResgataMaiorID());
	    	iv.setQuantidade(row.getQuantidade());
	    	ivdao.InserirItemVenda(iv);
	    }
	    LimpaCampos();
	    contagem = 0;
	    ExibeMensagem("Venda cadastrada", "Venda cadastrada com Sucesso!", "A venda foi inserido na base de dados!");
	}
	
	public void showConfirmationVenda () throws SQLException {
		if (contagem == 0) {
			ExibeMensagem("Escolha pelo menos 1 Produto!", "Escolha pelo menos 1 Produto!", "N�o � poss�vel cadastrar uma venda sem nenhum produto!");
			return;
		}
		
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Venda");
        alert.setHeaderText("Tem certeza de que deseja Registrar esta venda?");
        alert.setContentText("Por favor, confirme a opera��o");
        Optional<ButtonType> option = alert.showAndWait();
   
        if (option.get() == null) {
           
        } else if (option.get() == ButtonType.OK) {
        	RegistrarVenda();
        } else if (option.get() == ButtonType.CANCEL) {
        	LimpaCampos();
        } else {
        }
     }
	
	public void LimpaCampos () {
		cbProdutos.setValue("");
		txtQuantidade.setText("");
		tbItens.getItems().clear();
		valor_total = 0;
		lblValor.setText(String.valueOf(valor_total));
		cbProdutos.requestFocus();
	}
	
	private void ExibeMensagem(String title, String header, String content) {
		Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
	}
}
