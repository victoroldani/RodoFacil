/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package samplefx.ctrl;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class FXML6Controller implements Initializable {

	@FXML
	TextField txtLargura = new TextField();
	
	@FXML
	ComboBox<String> cbDepartamento = new ComboBox<String>();
	
	@FXML
	Button btnSalvarProd = new Button();
	
	@FXML
	Button btnExcluirProd = new Button();
	
	@FXML
	Button btnExcluirDep = new Button();
	
	@FXML
	Button btnAltDep = new Button();
	
	@FXML
	ComboBox<String> cbProduto_alt = new ComboBox<String>();
	
	@FXML
	Button btnCancelarDep = new Button();
	
	@FXML
	TextField txtDepNome_alt = new TextField();
	
	@FXML
	ComboBox<String> cbDepartamento_alt = new ComboBox<String>();
	
	@FXML
	TextField txtPreco = new TextField();
	
	@FXML
	TextField txtAltura = new TextField();
	
	@FXML
	TextField txtComprimento = new TextField();
	
	@FXML
	Button btnCancelarProd = new Button();
	
	private static Connection connection;
	ProdutoDao pdao = new ProdutoDao();
	DepartamentoDao ddao = new DepartamentoDao(); 
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	connection = DbUtil.getConnection();
        // TODO
    	ObservableList<String> Lista = FXCollections.observableArrayList();
    	ResultSet rs;
		try {
			rs = connection.createStatement().executeQuery("SELECT * FROM departamento;");
			while (rs.next()) {
				Lista.add(new String(rs.getString("nome"))); 
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		cbDepartamento.getItems().addAll(Lista);
		new ComboBoxAutoComplete<String>(cbDepartamento);
		
		ObservableList<String> Lista2 = FXCollections.observableArrayList();
    	ResultSet rs2;
		try {
			rs2 = connection.createStatement().executeQuery("SELECT * FROM produto;");
			while (rs2.next()) {
				Lista2.add(new String(rs2.getString("nome"))); 
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		cbProduto_alt.getItems().addAll(Lista2);
		new ComboBoxAutoComplete<String>(cbProduto_alt);
		
		ObservableList<String> Lista3 = FXCollections.observableArrayList();
    	ResultSet rs3;
		try {
			rs3 = connection.createStatement().executeQuery("SELECT * FROM departamento;");
			while (rs3.next()) {
				Lista3.add(new String(rs3.getString("nome"))); 
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		cbDepartamento_alt.getItems().addAll(Lista3);
		new ComboBoxAutoComplete<String>(cbDepartamento_alt);
    }  

    public void AlterarProduto () {
    	if (cbProduto_alt.getSelectionModel().getSelectedIndex() == -1) {
    		ExibeMensagem("Produto", "Selecione um produto!", "Selecione um produto!");
    		return;
    	}
    	
    	if (txtPreco.getText().length() == 0 && txtAltura.getText().length() == 0 && txtLargura.getText().length() == 0 && txtComprimento.getText().length() == 0 && cbDepartamento.getSelectionModel().getSelectedIndex() == -1) {
    		ExibeMensagem("Produto", "Preencha pelo menos um campo para ser alterado!", "Preencha pelo menos um campo para ser alterado!");
    		return;
    	}
    	
    	if (txtPreco.getText().length() != 0) {
    		try {
    			Double.parseDouble(txtPreco.getText());
    			if (Double.parseDouble(txtPreco.getText()) < 0 || Double.parseDouble(txtPreco.getText()) > 999) {
					throw new IllegalArgumentException("");
				}
    		} catch (Exception e){
    			ExibeMensagem("Pre�o", "O pre�o deve ser num�rico e separado por '.', maior que zero e menor que R$999!", "O pre�o deve ser num�rico, separado por '.', maior que zero  e menor que R$999!!");
    			return;
    		}
    	}
    	
    	if (txtAltura.getText().length() != 0) {
    		try {
    			Integer.parseInt(txtAltura.getText());
    			if (Integer.parseInt(txtAltura.getText()) < 0) {
					throw new IllegalArgumentException("");
				}
    		} catch (Exception e){
    			ExibeMensagem("Altura", "A altura deve ser num�rica, inteira, maior que zero e menor que 999!", "A altura deve ser num�rica, inteira, maior que zero e menor que 999!");
    			return;
    		}
    	}
    	
    	if (txtLargura.getText().length() != 0) {
    		try {
    			Integer.parseInt(txtLargura.getText());
    			if (Integer.parseInt(txtLargura.getText()) < 0) {
					throw new IllegalArgumentException("");
				}
    		} catch (Exception e){
    			ExibeMensagem("Largura", "A Largura deve ser num�rica, inteira, maior que zero e menor que 999!", "A Largura deve ser num�rica, inteira, maior que zero e menor que 999!");
    			return;
    		}
    	}
    	
    	if (txtComprimento.getText().length() != 0) {
    		try {
    			Integer.parseInt(txtComprimento.getText());
    			if (Integer.parseInt(txtComprimento.getText()) < 0) {
					throw new IllegalArgumentException("");
				}
    		} catch (Exception e){
    			ExibeMensagem("Comprimento", "O Comprimento deve ser num�rica, inteira, maior que zero e menor que 999!", "O Comprimento deve ser num�rica, inteira e maior que zero, e menor que 999!");
    			return;
    		}
    	}

    	//(String nome, double preco, int altura, int largura, int comprimento)
    	Produto p = new Produto("", 0,0,0,0, "");
    	
    	p.setNome(cbProduto_alt.getValue().toString());
    	
    	if (txtPreco.getText().length() != 0) {
    		p.setPreco(Double.parseDouble(txtPreco.getText()));
    	}
    	else {
    		p.setPreco(0);
    	}
    	
    	if (txtAltura.getText().length() != 0) {
    		p.setAltura(Integer.parseInt(txtAltura.getText()));
    	}
    	else {
    		p.setAltura(0);
    	}
    	
    	if (txtLargura.getText().length() != 0) {
    		p.setLargura(Integer.parseInt(txtLargura.getText()));
    	}
    	else {
    		p.setLargura(0);
    	}
    	
    	if (txtComprimento.getText().length() != 0) {
    		p.setComprimento(Integer.parseInt(txtComprimento.getText()));
    	}
    	else {
    		p.setComprimento(0);
    	}
    	
    	if (cbDepartamento.getSelectionModel().getSelectedItem() != null) {
    		p.setDepartamento(cbDepartamento.getValue().toString());
    	}
    	else {
    		p.setDepartamento("");
    	}
    	
    	pdao.AlterarProduto(p);
    	AlertaAlterarProd();
    	CancelarProd();
    }
    
    public void AlterarDepartamento () throws SQLException {
    	
    	if (cbDepartamento_alt.getSelectionModel().getSelectedIndex() == -1 || txtDepNome_alt.getText().length() == 0) {
    		ExibeMensagem("Departamento", "Preencha os campos corretamente!", "Preencha os campos corretamente!");
    		return;
    	}
    	//(String nome, double preco, int altura, int largura, int comprimento)
    	Departamento d = new Departamento();
    	if (cbDepartamento_alt.getSelectionModel().getSelectedItem() != null) {
    		d.setNome(cbDepartamento_alt.getValue().toString());
    		ddao.AlterarDepartamento(d, txtDepNome_alt.getText());
    		AlertaAlterarDep();
    		CancelarDep();
    	}
    }
    
    public void CancelarProd () {
    	cbProduto_alt.setValue("");
    	txtPreco.clear();
    	txtAltura.clear();
    	txtLargura.clear();
    	txtComprimento.clear();
    	cbDepartamento.setValue("");
    	cbProduto_alt.requestFocus();
    	cbProduto_alt.getSelectionModel().clearAndSelect(-1);
    }
    
    public void CancelarDep () {
    	txtDepNome_alt.clear();
    	cbDepartamento_alt.setValue("");
    	cbDepartamento_alt.requestFocus();
    	cbDepartamento_alt.getSelectionModel().clearAndSelect(-1);
    }
    
    public void ExcluirDepartamento (ActionEvent event) throws SQLException {
    	if (cbDepartamento_alt.getSelectionModel().getSelectedIndex() == -1) {
    		ExibeMensagem("Departamento", "Selecione um departamento para ser exclu�do!", "Selecione um departamento!");
    		return;
    	}
    	showConfirmationDep();
    }
    
    public void ExcluirProduto (ActionEvent event) throws SQLException {
    	if (cbProduto_alt.getSelectionModel().getSelectedIndex() == -1) {
    		ExibeMensagem("Produto", "Selecione um produto para ser exclu�do!", "Selecione um produto!");
    		return;
    	}
    	showConfirmationProd();
    }
    
    private void showConfirmationProd() {
    	Produto p = new Produto("", 0,0,0,0, "");
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Deletar Produto");
        alert.setHeaderText("Tem certeza de que deseja excluir este produto?");
        alert.setContentText("Por favor, confirme a opera��o");
        
        // option != null.
        Optional<ButtonType> option = alert.showAndWait();
   
        if (option.get() == null) {
           
        } else if (option.get() == ButtonType.OK) {
        	
        	if (cbProduto_alt.getSelectionModel().getSelectedItem() != null) {

				 p.setNome(cbProduto_alt.getValue().toString());
	    		 try {
					pdao.ExcluirProduto(p);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    		 showAlertWithHeaderTextProd();
	    		 CancelarProd();
			 }
           
        } else if (option.get() == ButtonType.CANCEL) {
        	CancelarProd();
        } else {
           
        }
     }
    
    public void showConfirmationProdAlt() {
    	if (cbProduto_alt.getSelectionModel().getSelectedIndex() == -1) {
    		ExibeMensagem("Produto", "Selecione um produto para ser alterado!", "Selecione um Produto!");
    		return;
    	}
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Deletar Produto");
        alert.setHeaderText("Tem certeza de que deseja Alterar este produto?");
        alert.setContentText("Por favor, confirme a opera��o");
        
        // option != null.
        Optional<ButtonType> option = alert.showAndWait();
   
        if (option.get() == null) {
           
        } else if (option.get() == ButtonType.OK) {

        		AlterarProduto();
        } else if (option.get() == ButtonType.CANCEL) {
        	CancelarProd();
        } else { }
     }
    
    public void showConfirmationDepAlt() throws SQLException {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Deletar Produto");
        alert.setHeaderText("Tem certeza de que deseja Alterar este departamento?");
        alert.setContentText("Por favor, confirme a opera��o");
        
        // option != null.
        Optional<ButtonType> option = alert.showAndWait();
   
        if (option.get() == null) {
           
        } else if (option.get() == ButtonType.OK) {
        	AlterarDepartamento();
        } else if (option.get() == ButtonType.CANCEL) {
        	CancelarProd();
        } else { }
     }
    
    private void showConfirmationDep() throws SQLException {
    	Departamento d = new Departamento();
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Deletar Produto");
        alert.setHeaderText("Tem certeza de que deseja excluir este departamento?");
        alert.setContentText("Os produtos associados a ele tamb�m ser�o exclu�dos!");
        
        // option != null.
        Optional<ButtonType> option = alert.showAndWait();
   
        if (option.get() == null) {
           
        } else if (option.get() == ButtonType.OK) {
        	
        	if (cbDepartamento_alt.getSelectionModel().getSelectedItem() != null) {

        		if (cbDepartamento_alt.getSelectionModel().getSelectedItem() != null) {
            		d.setNome(cbDepartamento_alt.getValue().toString());
            		ddao.ExcluirDepartamento(d);
            		showAlertWithHeaderTextDep();
            		CancelarDep();
			 }
        	}
        } else if (option.get() == ButtonType.CANCEL) {
        	CancelarDep(); 
        }
    } 
      
    private void ExibeMensagem(String title, String header, String content) {
		Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
	}
    
    private void AlertaAlterarProd() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Altera��o");
        alert.setHeaderText("Produto Alterado.");
        alert.setContentText("Os Dados do Produto foram alterados com Sucesso!");
        alert.showAndWait();
    }
    
    private void AlertaAlterarDep() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Altera��o");
        alert.setHeaderText("Departamento Alterado.");
        alert.setContentText("Os Dados do Departamento foram alterados com Sucesso!");
        alert.showAndWait();
    }
    
    private void showAlertWithHeaderTextProd() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Exclus�o");
        alert.setHeaderText("Produto exclu�do.");
        alert.setContentText("O Produto foi exclu�do da Base de Dados com Sucesso!");
        alert.showAndWait();
    }
    
    private void showAlertWithHeaderTextDep() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Exclus�o");
        alert.setHeaderText("Departamento exclu�do.");
        alert.setContentText("O Departamento e os produtos associados � ele foram exclu�dos da Base de Dados com Sucesso!");
        alert.showAndWait();
    }
}